exports.index = function(req, res){
  res.redirect('/users');
};
